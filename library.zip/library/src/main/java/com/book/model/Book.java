package com.book.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


@Entity
@Table(name = "book")

public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", nullable = false)
	@NotNull(message = "Id can not be null")
	private int id;

	@Column(name = "bname")
	@NotNull(message = "Name can not be null")
	@NotEmpty(message = "Name can not be empty")
	@Size(min = 5, max = 32, message = "Name must be min 5 characters")
	private String bname;
	
	@Column(name = "nameauth")
	@NotNull(message = "Author Name can not be null")
	@NotEmpty(message = "Author Name can not be empty")
	@Size(min = 5, max = 32, message = "Name must be min 5 characters")
	//@Pattern(regexp = "^[A-Za-z]+$",message ="Must be alphabets only" )
	@Pattern(regexp = "^[a-zA-z]+([\\s][a-zA-Z]+)*$",message ="Must be alphabets only" )
	private String nameauth;

	@Column(name = "nocopies")
	@NotNull(message = "no_of_copies can not be null")
	//@Pattern(regexp="^[0-9]+$", message ="Must be numeric only") 
	private int nocopies;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getNameauth() {
		return nameauth;
	}

	public void setNameauth(String nameauth) {
		this.nameauth = nameauth;
	}

	public int getNocopies() {
		return nocopies;
	}

	public void setNocopies(int nocopies) {
		this.nocopies = nocopies;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", bname=" + bname + ", nameauth=" + nameauth + ", nocopies=" + nocopies + "]";
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Book(@NotNull(message = "Id can not be null") int id,
			@NotNull(message = "Name can not be null") @NotEmpty(message = "Name can not be empty") @Size(min = 5, max = 32, message = "Name must be min 5 characters") String bname,
			@NotNull(message = "Author Name can not be null") @NotEmpty(message = "Author Name can not be empty") @Size(min = 5, max = 32, message = "Name must be min 5 characters") @Pattern(regexp = "^[a-zA-z]+([\\s][a-zA-Z]+)*$", message = "Must be alphabets only") String nameauth,
			@NotNull(message = "no_of_copies can not be null") int nocopies) {
		super();
		this.id = id;
		this.bname = bname;
		this.nameauth = nameauth;
		this.nocopies = nocopies;
	}
	
	


}
