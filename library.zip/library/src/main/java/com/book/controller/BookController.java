package com.book.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.book.BookRepo;
import com.book.dao.Dao;
import com.book.model.Book;


@Controller
//@RequestMapping("/")
public class BookController {
	@Autowired
	private BookRepo rep;
	@Autowired
	private Dao dao;
	@GetMapping
	public String welcome() {
		return "home";
	}
	 @RequestMapping("/add")    
	    public String showform(Model m){    
	        m.addAttribute("book", new Book());  
	        return "bookform";   
	    }  
	 @RequestMapping(value="/save",method = RequestMethod.POST)    
	    public String save(@Valid @ModelAttribute("book") Book book , BindingResult result){ 
		 if (result.hasErrors()) {
				return "bookform";
			} else {
	        dao.save(book);    
	        return "sucess";}  
	    }   
	
	
	    @RequestMapping("/viewbook")    
	    public String viewemp(Model m){    
	        List<Book> list=rep.findAll();    
	        m.addAttribute("list",list);  
	        return "showbook";    
	    }    
	
	    @RequestMapping(value="/editbook")    
	    public String edit(@RequestParam int id, Model m){    
	        Book book=dao.getBooksById(id);    
	        m.addAttribute("book",book);  
	        return "edit";    
	    }    
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@Valid @ModelAttribute("book") Book book , BindingResult result){ 
	    	if (result.hasErrors()) {
				return "edit";
			} else {
	    	 dao.save(book);    
	        return "sucess";  }  
	    }    
	    
	    @RequestMapping(value="/deletebook",method = RequestMethod.GET)    
	    public String delete(@RequestParam int id){    
	    	dao.delete(id);     
	        return "sucess";    
	    }  
	   

}
