package com.book.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.book.BookRepo;
import com.book.model.Book;


@Component
public class Dao {
	@Autowired
	private BookRepo rep;
   public Book getBooksById(int id) 
   {  
   return rep.findById(id).get();
   } 
   
   public void save(Book book) {
		rep.save(book);
}	
   /*public void update(Book book)   
   {  
     rep.save(book);  
   } */
   public void delete(int id)   
   {  
   rep.deleteById(id);  
   }  
}
